public class Jump {
	// OVERVIEW: A Jump is an immutable datatype that represents a move on
	//     a peg board.  A typical jump is < start, hop, land > where
	//     start, hop and land are numbers representing locations on the board.

	private int start, hop, land;
	
	public Jump (int p_start, int p_hop, int p_land) {
		start = p_start; 
		hop = p_hop;
		land = p_land;
	}
	
	public int getStart () {
		return start;
	}
	
	public int getHop () {
		return hop;
	}
	
	public int getLand () {
		return land;
	}
	
	public String toString () {
		return start + " - " + land;
	}
}
