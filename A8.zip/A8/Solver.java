import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;

public class Solver {
	// OVERVIEW: Solver is the top-level class.  It provides methods for
	//     reading in a board, and solving the game.

	// EFFECTS: If it is possible to win from b, returns a sequence of
	//    moves that transforms b into a board with a single peg.  If
	//    no such sequence exists, throws NoWinnerException.
	//    (Note: the board with 0 pegs is a losing board.)
	//@ensures \result != null 
	//@requires b != null
	static public JumpList solve(BoardState b) throws NoWinnerException {
		JumpList jumps = b.possibleJumps();

		for (Enumeration e = jumps.elements(); e.hasMoreElements();) {
			Jump j = (Jump) e.nextElement(); //@nowarn Cast
			//@assume j != null
			// Try this jump
			b.executeJump(j);
			// See if there is a winning solution
			JumpList winningmoves;

			try {
				winningmoves = solve(b);
			} catch (NoWinnerException nwe) {
				continue; // Try the next possible jump
			} finally {
				b.reverseJump(j);
				// Reverse the jump (restore b to its original state)
				// Note ths finally block will run after the try and catch blocks, whether
				// or not the exception is caught.
			}

			// There is a winning sequence: add this jump to the front of it, and return:
			winningmoves.insertJump(j);
			return winningmoves;
		}

		// Tried all moves
		if (b.numPegs() == 1) {
			// If there's one peg, its a winner
			return new JumpList();
		} else {
			throw new NoWinnerException();
		}
	}
	
	static public void errorExit(String msg) {
		System.err.println(msg);
		System.exit(-1);
	}

	//@requires args != null
	static public void main(String[] args) {
		String cfile = "cracker.cb";
		
		System.out.println("     o\r\n" + 
				           "    * *\r\n" + 
				           "   * * *\r\n" + 
				           "  * * * *\r\n" + 
				           " * * * * *");
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(cfile));
		} catch (FileNotFoundException e) {
			errorExit("Error: cannot open configuration file: " + cfile);
			return; // Compiler can't figure out errorExit never returns
		}

		String firstline;
		try {
			firstline = reader.readLine();
		} catch (IOException e1) {
			errorExit("Error: problem reading first line: " + e1);
			return;
		}
		int numrows = Integer.parseInt(firstline);

		if (numrows < 1) {
			errorExit("Error: the first line of the configuration file must be a number >= 1.");
			return;
		}

		Board b = new Board(numrows);
		BoardState bs = new BoardState(b);

		int rowno = 1;
		int pegno = 0;
		int inchar;

		try {
			while ((inchar = reader.read()) != -1) {
				char c = (char) inchar;

				if (c == ' '
					|| c == '\t'
					|| c == '\r') { // skip whitespace characters
				} else if (c == '\n') {
					rowno++;
				} else if (c == '*' || c == 'o') {
					pegno++;
					if (c == '*')
						bs.addPeg(pegno);
					if (b.getSquareRow(pegno) != rowno) {
						errorExit(
							"Row "
								+ rowno
								+ " in the configuration file "
								+ cfile
								+ " contains the wrong number of pegs.");
					}
				} else {
					System.err.println(
						"Skipping unrecognized character in configuration file: "
							+ c);
				}
			}
		} catch (IOException e2) {
			errorExit("Error: IO error reading file: " + e2);
		} catch (NotOnBoardException e2) {
			errorExit(
				"The configuration file contains too many pegs.  Read peg "
					+ pegno
					+ ".");
		}

		if (pegno != b.numberOfSquares()) {
			errorExit(
				"The configuration file does not contain enough information.  Only "
					+ pegno
					+ " peg or holes,  when "
					+ b.numberOfSquares()
					+ " is expected.");
		}

		//System.out.println("Read board containing " + bs.numPegs() + " pegs...");

		try {
			JumpList winning = solve(bs);
			System.out.println("Winning moves: \n" + winning);
		} catch (NoWinnerException nwe) {
			System.out.println("There is no winning sequence for the board.");
		}
	} //@nowarn Exception
}
