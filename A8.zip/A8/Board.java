public class Board {
	private int numrows;

	//@invariant numrows >= 1

	//@requires p_numrows >= 1
	public Board(int p_numrows) {
		numrows = p_numrows;
	}

	//@ensures \result >= 1
	public int numberOfSquares() {
		// EFFECTS: Returns the number of squares on this board.
		return calculateNumberOfSquares(numrows);
	}

	//@ensures \result >= 1
	private int calculateNumberOfSquares(int rows) {
		// The one row board has 1 square:
		if (rows == 1) {
			return 1;
		} else {
			// A board with more rows, is a square, with the triangle
			// of one size smaller removed
			return (rows * rows) - calculateNumberOfSquares(rows - 1);
		}
	} //@nowarn Post // can't prove >= 1

	//@requires square >= 1
	public int getSquareRow(int square) throws NotOnBoardException {
		if (square < 1)
			throw new NotOnBoardException();
		int firstsquare = 1;

		for (int rowno = 1; rowno <= numrows; rowno++) {
			if (square - firstsquare < rowno) {
				return rowno;
			}
			firstsquare += rowno;
		}
		if (square <= numberOfSquares()) {
			Assert.error ("Error: Should have found a row!");
		}

		throw new NotOnBoardException();
	}

	//@ensures \result >= 1
	// EFFECTS: If row, col is on the board, returns the square number
	//    corresponding to row, col.  Otherwise, throws NotOnBoardException.
	public int squareAt(int row, int col) throws NotOnBoardException {
		if (row < 1 || col < 1)
			throw new NotOnBoardException("squareAt: " + row + ", " + col);
		if (col > row) 
			throw new NotOnBoardException("squareAt: " + row + ", " + col);
		
		int squareno = 0;
		for (int rowno = 1; rowno < row; rowno++) {
			squareno += rowno;
		}

		squareno += col;
		
		Assert.check(getSquareRow(squareno) == row);
		Assert.check(getSquareColumn(squareno) == col);
		return squareno;
	}

	//@requires square >= 1
	public int getSquareColumn(int square) throws NotOnBoardException {
		if (square < 1)
			throw new NotOnBoardException();
		int firstsquare = 1;

		for (int rowno = 1; rowno <= numrows; rowno++) {
			if (square - firstsquare < rowno) {
				return (square - firstsquare) + 1;
			}
			firstsquare += rowno;
		}

		if (square <= numberOfSquares()) {
			Assert.error ("Error: Should have found a row!");
		}

		throw new NotOnBoardException();
	}

	//@requires direction != null;
	//@ensures \result >= 1
	//         and \result <= numberOfSquares ()
	// EFFECTS: Returns the number of the position that is reached starting
	//    from the start position, and moving steps number of steps in the
	//    direction.  If the resulting position is not on the board, throws
	//    NotOnBoardException.
	public int getSquare(int start, Direction direction, int steps)
		throws NotOnBoardException {
		if (start < 1) throw new NotOnBoardException ();
		
		int startrow = getSquareRow(start);
		int startcol = getSquareColumn(start);

		int newrow;
		int newcol;

		if (direction.isEast()) {
			newrow = startrow;
			newcol = startcol + steps;
		} else if (direction.isWest()) {
			newrow = startrow;
			newcol = startcol - steps;
		} else if (direction.isNorthEast()) {
			newrow = startrow - steps;
			newcol = startcol;
		} else if (direction.isNorthWest()) {
			newrow = startrow - steps;
			newcol = startcol - steps;
		} else if (direction.isSouthEast()) {
			newrow = startrow + steps;
			newcol = startcol + steps;
		} else if (direction.isSouthWest()) {
			newrow = startrow + steps;
			newcol = startcol;
		} else {
			Assert.error ("Bad direction!");
			return 1; // Never reached 
		}

		return squareAt(newrow, newcol);
	} 

	// This is for testing only
	static public void main(String args[]) throws NotOnBoardException {
		Board b = new Board(5);

		System.err.println("Number of squares (15): " + b.numberOfSquares());
		for (int i = 1; i <= b.numberOfSquares(); i++) {
			System.err.println(
				"Square "
					+ i
					+ ": "
					+ b.getSquareRow(i)
					+ ", "
					+ b.getSquareColumn(i));
		}

		try {
			b.getSquareRow(b.numberOfSquares() + 1);
			System.err.println("ERROR: Should be off board!");
		} catch (NotOnBoardException e) {
			System.err.println("Off board: okay");
		}

		System.err.println(
			"southwest 1 (2, 1 = 2): "
				+ b.getSquare(1, Direction.makeSouthWest(), 1));
		System.err.println(
			"southwest 2 (3, 1 = 4): "
				+ b.getSquare(1, Direction.makeSouthWest(), 2));
		System.err.println(
			"southwest 1 (2, 2 = 3): "
				+ b.getSquare(1, Direction.makeSouthEast(), 1));
		System.err.println(
			"southwest 2 (3, 3 = 6): "
				+ b.getSquare(1, Direction.makeSouthEast(), 2));

		System.err.println(
			"west 10, 2 = 8: " + b.getSquare(10, Direction.makeWest(), 2));
		System.err.println(
			"east 8, 2 = 10: " + b.getSquare(8, Direction.makeEast(), 2));

		System.err.println(
			"northwest 5, 1 = 2: "
				+ b.getSquare(5, Direction.makeNorthWest(), 1));

		System.err.println(
			"northeast 5, 1 = 3: "
				+ b.getSquare(5, Direction.makeNorthEast(), 1));

		try {
			System.err.println(
				"northeast 5, 2 = ERROR"
					+ b.getSquare(5, Direction.makeNorthEast(), 2));
		} catch (NotOnBoardException e) {
			System.err.println("Off board: okay");
		}
	}
}
