import java.util.Enumeration;
import java.util.Vector;

public class Direction {
	// OVERVIEW: Direction is an immutable datatype that represents a direction 
	//     on the peg board.  A Direction is one of 
	//            EAST, WEST, NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST

	static final private int EAST = 0;
	static final private int WEST = 1;
	static final private int NORTHEAST = 2;
	static final private int NORTHWEST = 3;
	static final private int SOUTHEAST = 4;
	static final private int SOUTHWEST = 5;
	static final private int LASTDIR = SOUTHWEST;

	//@invariant rep == EAST || rep == WEST || rep == NORTHEAST || rep == NORTHWEST || rep == SOUTHEAST || rep == SOUTHWEST
	private int rep;

	//@requires dir == EAST || dir == WEST || dir == NORTHEAST || dir == NORTHWEST || dir == SOUTHEAST || dir == SOUTHWEST
	private Direction(int dir) {
		rep = dir;
	}

	//@ensures \result != null
	static public Direction makeEast() {
		return new Direction(EAST);
	}

	public boolean isEast() {
		return rep == EAST;
	}

	//@ensures \result != null
	static public Direction makeWest() {
		return new Direction(WEST);
	}

	public boolean isWest() {
		return rep == WEST;
	}

	//@ensures \result != null
	static public Direction makeNorthEast() {
		return new Direction(NORTHEAST);
	}

	public boolean isNorthEast() {
		return rep == NORTHEAST;
	}

	//@ensures \result != null
	static public Direction makeNorthWest() {
		return new Direction(NORTHWEST);
	}

	public boolean isNorthWest() {
		return rep == NORTHWEST;
	}

	//@ensures \result != null	
	static public Direction makeSouthEast() {
		return new Direction(SOUTHEAST);
	}

	public boolean isSouthEast() {
			return rep == SOUTHEAST;
		}

	//@ensures \result != null
	static public Direction makeSouthWest() {
		return new Direction(SOUTHWEST);
	}

	public boolean isSouthWest() {
			return rep == SOUTHWEST;
		}

	//@ensures \result != null
	static public Enumeration allDirections() {
		Vector dirs = new Vector();
		//@set dirs.elementType = \type(Direction)
		for (int i = 0; i <= LASTDIR; i++) {
			dirs.add(new Direction(i));
		}
		return dirs.elements();
	}

	public String toString() {
		switch (rep) {
			case EAST :
				return "east";
			case WEST :
				return "west";
			case NORTHEAST :
				return "northeast";
			case NORTHWEST :
				return "northwest";
			case SOUTHEAST :
				return "southeast";
			case SOUTHWEST :
				return "southwest";
		}

		throw new RuntimeException("The Direction invariant is broken!");
	}
}
