import java.util.Enumeration;

public class BoardState {
	// OVERVIEW: BoardState is a mutable datatype that keeps track of the pegs on
	//     a board.  A typical board state is
	//                         o  
	//                        * *
	//                       * * *
	//                      * * * *
	//                     * * * * *

	// Rep:
	private boolean [] pegs;
	private Board board;

	//@invariant pegs != null;
	//@invariant board != null;
	// invariant All the elements of pegs are either 0, or unique positive integers.
	//           (0 can appear in pegs more than once, any other number can only appear once).

	// Abstraction Fuction:
	//   AF (r) =  
	//              p_1
	//           p_2    p_3
	//         ...
	//
	//    where p_i = '*' if pegs[i - 1] == true
	//          p_i = 'o' otherwise
	//

	//@requires b != null
	// EFFECTS: Creates a BoardState for board b with no pegs
	public BoardState(Board b) {
		pegs = new boolean [b.numberOfSquares()];
		board = b;
	}

	// EFFECTS: Returns true iff the location square contains a peg in this.
	//     
	public boolean containsPeg (int square) throws NotOnBoardException {
		if (square < 1 || square > pegs.length) {
			throw new NotOnBoardException ();
		}
		
		return pegs[square - 1];
	}
	
	// EFFECTS: Adds the square to this.
	public void addPeg(int square) throws NotOnBoardException {
		if (square < 1 || square > pegs.length) {
			throw new NotOnBoardException ();
		}
		
		pegs[square - 1] = true;
	}
		
	// REQUIRES: square is in this.
	// EFFECTS: Removes a peg at square from this.
	public void removePeg(int square) throws NotOnBoardException {
		if (square < 1 || square > pegs.length) {
			throw new NotOnBoardException ();
		}
		
		pegs[square - 1] = false;
	}		
		

	// EFFECTS: Returns the number of pegs in this.	
	public int numPegs() {
		int count = 0;

		for (int i = 0; i < pegs.length; i++) {
			if (pegs[i])
				count++;
		}

		return count;
	}

	//@requires jump != null
	// REQUIRES: jump is a legal jump on this.
	// EFFECTS: Modifies this reflect executing jump.  this_post is the
	//    board the results from executing jump on this_pre.	
	public void executeJump (Jump jump) {
		try {
			removePeg (jump.getStart ());
			removePeg (jump.getHop ());
			addPeg (jump.getLand ());					
		} catch (NotOnBoardException nbe) {
			Assert.error ("Error: jump is not on the board");
		}
	}
	
	//@requires jump != null;
	// REQUIRES: jump is a legal "reverse" jump on this.
	// EFFECTS: Modifies this to the board before taking jump.  this_post is the
	//    board the from which this_pre would result after taking jump.	
	public void reverseJump (Jump jump) {
		try {
			addPeg (jump.getStart ());
			addPeg (jump.getHop ());
			removePeg (jump.getLand ());					
		} catch (NotOnBoardException nbe) {
			Assert.error ("Error: jump is not on the board");
		}
	}

	//@requires jump != null;
	// REQUIRES: jump would be a legal jump on the board, if the
	//              first and second squares have pegs, and the
	//              third square is empty.
	// EFFECTS: Returns true if jump is a legal jump on this.
	private boolean legalJump (Jump jump) {
		try {
			return (containsPeg (jump.getStart ())
					&& containsPeg (jump.getHop ())
					&& !containsPeg (jump.getLand ()));					
		} catch (NotOnBoardException nbe) {
			Assert.error ("Error: jump is not on the board");
			return false;
		}
	}
	
	// EFFECTS: Returns a list of all jumps possible on this.
	//@ensures \result != null	
	public JumpList possibleJumps() {
		JumpList res = new JumpList();

		// For each peg, find all the possible jumps for that peg
		for (int i = 0; i < pegs.length; i++) {
			if (pegs[i]) {
				// Try each direction
				int startsquare = i + 1;

				for (Enumeration dirs = Direction.allDirections();
					dirs.hasMoreElements();
					) {
					// We can jump in direction d
					Direction d = (Direction) dirs.nextElement(); //@nowarn Cast
					//@assume d != null
					try {
						int middlesquare = board.getSquare(startsquare, d, 1);
						int endsquare = board.getSquare(startsquare, d, 2);
						Jump jump =
							new Jump(startsquare, middlesquare, endsquare);
						if (legalJump(jump)) {
							res.add(jump);
						}
					} catch (NotOnBoardException nbe) {
						// Not a legal jump - would fall off the board

					}

				}

			}
		}
		return res;
	}
}
