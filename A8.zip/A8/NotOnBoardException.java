public class NotOnBoardException extends Exception {
	public NotOnBoardException () { super (); }
	public NotOnBoardException (String s) { super (s); }
}
