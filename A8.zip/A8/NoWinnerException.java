public class NoWinnerException extends Exception {
	public NoWinnerException () { super (); }
	public NoWinnerException (String s) { super (s); }
}
