public class Assert {
	// OVERVIEW: Provides methods for checking assertions.
	
	static public void check (boolean b) {
		if (!b) {
			throw new RuntimeException ("Assertion Failed");
		}
	} //@nowarn Exception

	static public void error (String s) {
		throw new RuntimeException ("ERROR: " + s);
	} //@nowarn Exception
}
