import java.util.Enumeration;
import java.util.Vector;

public class JumpList {
	// OVERVIEW: A JumpList is a mutable datatype that represents a list of jumps.
	//     A typical JumpList is [ j0, j1, ..., jn-1 ]

	// Rep:
	private Vector rep;

	// Abstraction F
	//@invariant rep != null	
	//@invariant rep.elementType == \type(Jump)
	//@invariant rep.containsNull == false

	// EFFECTS: Initializes this to the empty JumpList = [].
	public JumpList() {
		rep = new Vector();
	} //@nowarn Invariant

	//@requires j != null
	// EFFECTS: Adds j at the end of this.  
	public void add(Jump j) {
		rep.add(j);
	}
	
	//@requires j != null
	// EFFECTS: Adds j at the beginning of this.
	public void insertJump(Jump j) {
		rep.add(0, j);
	}

	// EFFECTS: Returns an enumeration that yields the elements of this.
	//@ensures \result != null
	public Enumeration elements() {
		return rep.elements();
	}

	// EFFECTS: Returns a string representation of this.
	public String toString() {
		String res = null;

		for (Enumeration els = rep.elements(); els.hasMoreElements();) {
			if (res == null) {
				res = "";
			} else {
				res = res + '\n';
			}
			res = res + els.nextElement().toString();
		}

		if (res == null) {
			return "No Moves";
		} else {
			return res;
		}
	}
}
